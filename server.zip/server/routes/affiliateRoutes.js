const express = require('express');
const router = express.Router();
const {
  createOrder,
  verifyAndSavePurchase,
  getEarnings,
  getLeaderboard
} = require('../controllers/affiliateController');
const auth = require('../middleware/auth');

router.post('/order', auth.user, createOrder);
router.post('/verify', auth.user, verifyAndSavePurchase);
router.get('/earnings', auth.user, getEarnings);
router.get('/leaderboard', auth.admin, getLeaderboard);

module.exports = router;
