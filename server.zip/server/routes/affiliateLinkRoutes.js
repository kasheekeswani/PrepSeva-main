const express = require('express');
const router = express.Router();

// Debug: Check auth middleware
let auth;
try {
  auth = require('../middleware/auth');
  console.log('✅ Auth middleware loaded:', typeof auth);
} catch (error) {
  console.error('❌ Auth middleware failed to load:', error.message);
  // Create a dummy auth middleware as fallback
  auth = (req, res, next) => {
    console.log('Using dummy auth middleware');
    next();
  };
}

const affiliateLinkController = require('../controllers/affiliateLinkController');

// Debug: Check if controller functions are loaded
console.log('Available controller functions:', Object.keys(affiliateLinkController));
console.log('generateAffiliateLink type:', typeof affiliateLinkController.generateAffiliateLink);

// Generate affiliate link
console.log('Setting up POST /generate route...');
router.post('/generate', auth, affiliateLinkController.generateAffiliateLink);

// Get all affiliate links for authenticated user
console.log('Setting up GET / route...');
router.get('/', auth, affiliateLinkController.getAffiliateLinks);

// Get available courses for affiliate marketing
console.log('Setting up GET /courses route...');
router.get('/courses', auth, affiliateLinkController.getAvailableCourses);

// Get single affiliate link
console.log('Setting up GET /:id route...');
router.get('/:id', auth, affiliateLinkController.getAffiliateLink);

// Update affiliate link
console.log('Setting up PUT /:id route...');
router.put('/:id', auth, affiliateLinkController.updateAffiliateLink);

// Delete affiliate link
console.log('Setting up DELETE /:id route...');
router.delete('/:id', auth, affiliateLinkController.deleteAffiliateLink);

// Generate QR code for affiliate link
console.log('Setting up GET /:id/qr route...');
router.get('/:id/qr', auth, affiliateLinkController.generateQRCode);

// Get analytics for affiliate link
console.log('Setting up GET /:id/analytics route...');
router.get('/:id/analytics', auth, affiliateLinkController.getAnalytics);

// Public routes for tracking (no auth required)
// Track click on affiliate link
console.log('Setting up POST /track/click/:code route...');
router.post('/track/click/:code', affiliateLinkController.trackClick);

// Track conversion
console.log('Setting up POST /track/conversion/:code route...');
router.post('/track/conversion/:code', affiliateLinkController.trackConversion);

console.log('✅ All routes configured successfully');

module.exports = router;