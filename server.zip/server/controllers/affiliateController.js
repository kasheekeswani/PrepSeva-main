const Razorpay = require('razorpay');
const Course = require('../models/Course');
const AffiliatePurchase = require('../models/AffiliatePurchase');
const AffiliateLink = require('../models/AffiliateLink');
const User = require('../models/User');

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

exports.createOrder = async (req, res) => {
  try {
    const { courseId, affiliateCode } = req.body;
    
    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: "Course not found" });

    let affiliateId = null;
    
    // Look up affiliate by code if provided
    if (affiliateCode) {
      const affiliateLink = await AffiliateLink.findOne({ code: affiliateCode });
      if (affiliateLink) {
        affiliateId = affiliateLink.affiliateId;
      }
    }

    const order = await razorpay.orders.create({
      amount: course.price * 100,
      currency: "INR",
      receipt: `receipt_course_${courseId}`,
      notes: {
        courseId,
        affiliateId,
        affiliateCode
      }
    });

    res.json({ order, affiliateId });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.verifyAndSavePurchase = async (req, res) => {
  try {
    const { courseId, affiliateCode, paymentId } = req.body;
    
    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: "Course not found" });

    let affiliateId = null;
    let affiliateLink = null;

    // Look up affiliate by code if provided
    if (affiliateCode) {
      affiliateLink = await AffiliateLink.findOne({ code: affiliateCode });
      if (affiliateLink) {
        affiliateId = affiliateLink.affiliateId;
        
        // Update affiliate link conversion tracking
        await AffiliateLink.findByIdAndUpdate(affiliateLink._id, {
          $inc: { conversions: 1 }
        });
      }
    }

    const commission = affiliateId ? (course.affiliateCommission / 100) * course.price : 0;

    const purchase = new AffiliatePurchase({
      course: courseId,
      buyer: req.user._id,
      affiliate: affiliateId,
      amountPaid: course.price,
      commissionEarned: commission,
      paymentId,
      affiliateCode: affiliateCode || null
    });

    await purchase.save();

    // Update affiliate link earnings if applicable
    if (affiliateLink) {
      await AffiliateLink.findByIdAndUpdate(affiliateLink._id, {
        $inc: { earnings: commission }
      });
    }

    res.json({ success: true, purchase });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getEarnings = async (req, res) => {
  try {
    const earnings = await AffiliatePurchase.aggregate([
      { $match: { affiliate: req.user._id } },
      { $group: { _id: null, total: { $sum: "$commissionEarned" } } }
    ]);

    res.json({ totalEarned: earnings[0]?.total || 0 });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getLeaderboard = async (req, res) => {
  try {
    const leaderboard = await AffiliatePurchase.aggregate([
      {
        $group: {
          _id: "$affiliate",
          totalCommission: { $sum: "$commissionEarned" },
          totalSales: { $sum: 1 }
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "affiliateUser"
        }
      },
      { $unwind: "$affiliateUser" },
      {
        $project: {
          name: "$affiliateUser.name",
          email: "$affiliateUser.email",
          totalCommission: 1,
          totalSales: 1
        }
      },
      { $sort: { totalCommission: -1 } },
      { $limit: 50 }
    ]);

    res.json(leaderboard);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};