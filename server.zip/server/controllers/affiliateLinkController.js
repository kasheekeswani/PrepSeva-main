// Debug version - let's isolate the issue
console.log('Loading affiliateLinkController...');

// Check if required models exist
let AffiliateLink, Course, User;
try {
  AffiliateLink = require('../models/AffiliateLink');
  console.log('✅ AffiliateLink model loaded');
} catch (error) {
  console.error('❌ AffiliateLink model failed to load:', error.message);
}

try {
  Course = require('../models/Course');
  console.log('✅ Course model loaded');
} catch (error) {
  console.error('❌ Course model failed to load:', error.message);
}

try {
  User = require('../models/User');
  console.log('✅ User model loaded');
} catch (error) {
  console.error('❌ User model failed to load:', error.message);
}

// Check if required packages exist
let crypto, QRCode;
try {
  crypto = require('crypto');
  console.log('✅ crypto module loaded');
} catch (error) {
  console.error('❌ crypto module failed to load:', error.message);
}

try {
  QRCode = require('qrcode');
  console.log('✅ QRCode module loaded');
} catch (error) {
  console.error('❌ QRCode module failed to load:', error.message);
}

// Simple test function to verify exports work
const testFunction = async (req, res) => {
  res.json({ message: 'Test function working' });
};

console.log('Controller functions being exported...');

module.exports = {
  generateAffiliateLink: testFunction,
  getAffiliateLinks: testFunction,
  getAffiliateLink: testFunction,
  trackClick: testFunction,
  trackConversion: testFunction,
  generateQRCode: testFunction,
  updateAffiliateLink: testFunction,
  deleteAffiliateLink: testFunction,
  getAnalytics: testFunction,
  getAvailableCourses: testFunction
};

console.log('✅ Controller exports completed');