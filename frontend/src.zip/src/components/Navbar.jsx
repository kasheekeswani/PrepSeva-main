// src/components/Navbar.jsx
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { logout, admin } = useAuth();

  return (
    <nav style={{ display: 'flex', justifyContent: 'space-between', padding: '1rem 2rem', backgroundColor: '#282c34', color: 'white' }}>
      <div style={{ display: 'flex', gap: '1.5rem' }}>
        <Link to="/dashboard" style={{ color: 'white', textDecoration: 'none' }}>Dashboard</Link>
        <Link to="/users" style={{ color: 'white', textDecoration: 'none' }}>User Stats</Link>
        <Link to="/questions" style={{ color: 'white', textDecoration: 'none' }}>Question Manager</Link>
        <Link to="/tests" style={{ color: 'white', textDecoration: 'none' }}>Test Creator</Link>
        <Link to="/notifications" style={{ color: 'white', textDecoration: 'none' }}>Notification Manager</Link>
      </div>
      <div>
        <span style={{ marginRight: '1rem' }}>{admin?.email}</span>
        <button onClick={logout} style={{ background: 'red', border: 'none', color: 'white', padding: '0.5rem 1rem', borderRadius: '5px' }}>
          Logout
        </button>
      </div>
    </nav>
  );
}


