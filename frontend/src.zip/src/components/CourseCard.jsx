import React from 'react';
import { useNavigate } from 'react-router-dom';

const CourseCard = ({ course, onBuyClick, isAdmin }) => {
  const navigate = useNavigate();

  const handleCardClick = () => navigate(`/courses/${course._id}`);

  return (
    <div
      onClick={handleCardClick}
      className="bg-white rounded-3xl shadow-xl hover:shadow-2xl p-5 cursor-pointer transition-transform transform hover:-translate-y-1 relative overflow-hidden group border border-gray-200 hover:border-blue-300"
    >
      {/* Hover gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/20 to-purple-50/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>

      {/* Thumbnail and Title */}
      <div className="relative z-10 flex gap-4 mb-4">
        <div className="w-24 h-24 rounded-xl overflow-hidden border shadow-sm group-hover:shadow-md transition-transform transform group-hover:scale-105">
          <img src={course.thumbnail} alt={course.title} className="object-cover w-full h-full" />
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-semibold text-gray-800 group-hover:text-blue-600 transition-colors">
            {course.title}
          </h2>
          <p className="text-sm text-gray-600 line-clamp-2">{course.description}</p>
        </div>
      </div>

      {/* Price & Commission */}
      <div className="flex justify-between items-center bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl p-3 border">
        <div className="flex items-center gap-2">
          💰
          <div>
            <p className="font-semibold text-gray-800">₹{course.price}</p>
            <p className="text-xs text-gray-500">Price</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          🎯
          <div>
            <p className="font-semibold text-green-600">{course.affiliateCommission}%</p>
            <p className="text-xs text-gray-500">Commission</p>
          </div>
        </div>
      </div>

      {/* Buy / Admin Indicator */}
      {!isAdmin ? (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onBuyClick(course);
          }}
          className="mt-4 w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-3 rounded-xl transition-transform transform hover:scale-105 active:scale-95"
        >
          Buy / Share
        </button>
      ) : (
        <div className="absolute top-4 right-4 bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-medium">
          Admin View
        </div>
      )}
    </div>
  );
};

export default CourseCard;
