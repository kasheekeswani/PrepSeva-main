// src/pages/NotificationManager.jsx
import { useState, useEffect } from 'react';
import API from '../services/api';

export default function NotificationManager() {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [notifications, setNotifications] = useState([]); // ✅ initialize as array
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchNotifications = async () => {
    try {
      const res = await API.get('/notifications');
      const data = Array.isArray(res.data) ? res.data : []; // ✅ safe check
      setNotifications(data);
    } catch (err) {
      console.error('Error fetching notifications:', err);
      setError('Failed to load notifications.');
    } finally {
      setLoading(false);
    }
  };

  const createNotification = async () => {
    try {
      await API.post('/notifications', { title, message });
      setTitle('');
      setMessage('');
      fetchNotifications();
    } catch (err) {
      console.error('Error creating notification:', err);
      alert('Failed to create notification');
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  if (loading) return <p>Loading notifications...</p>;
  if (error) return <p style={{ color: 'red' }}>{error}</p>;

  return (
    <div style={{ padding: '2rem' }}>
      <h2>Create Notification</h2>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        style={{ display: 'block', width: '100%', padding: '0.5rem', marginBottom: '1rem' }}
      />
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Message"
        style={{ display: 'block', width: '100%', padding: '0.5rem', marginBottom: '1rem', minHeight: '100px' }}
      />
      <button
        onClick={createNotification}
        style={{ backgroundColor: '#007bff', color: 'white', padding: '0.5rem 1rem', border: 'none', borderRadius: '4px' }}
      >
        Create
      </button>

      <h3 style={{ marginTop: '2rem' }}>All Notifications</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {notifications.length === 0 ? (
          <li>No notifications found.</li>
        ) : (
          notifications.map((n, i) => (
            <li key={i} style={{ marginBottom: '1rem', padding: '1rem', backgroundColor: '#f8f9fa', borderRadius: '6px' }}>
              <strong>{n.title}</strong>
              <p>{n.message}</p>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
