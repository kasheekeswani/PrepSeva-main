// src/pages/UserStats.jsx
import { useEffect, useState } from 'react';
import API from '../services/api';

export default function UserStats() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await API.get('/stats/users');
        setStats(res.data);
      } catch (err) {
        console.error('Error fetching user stats:', err);
        setError('Failed to load user stats.');
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p style={{ color: 'red' }}>{error}</p>;

  return (
    <div style={{ padding: '2rem' }}>
      <h2>User Statistics</h2>

      <div style={{ display: 'flex', gap: '2rem', margin: '1rem 0' }}>
        <div><strong>Total Users:</strong> {stats?.totalUsers ?? 0}</div>
        <div><strong>Active (7 days):</strong> {stats?.activeUsers ?? 0}</div>
        <div><strong>Avg Tests/User:</strong> {stats?.avgTestsPerUser ?? 0}</div>
      </div>

      <h3>User Test Table</h3>
      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Tests Completed</th>
          </tr>
        </thead>
        <tbody>
          {(stats?.userTestData ?? []).map((user) => (
            <tr key={user._id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.testCount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
