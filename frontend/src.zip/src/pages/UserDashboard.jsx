// src/pages/UserDashboard.jsx
import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import API, { getAffiliateEarnings } from '../services/api';

export default function UserDashboard() {
  const { user, isUser, logout } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [earnings, setEarnings] = useState(0);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (!user || !isUser) {
      navigate('/');
      return;
    }

    const fetchStats = async () => {
      try {
        const res = await API.get(`/userstats/${user._id}`);
        setStats(res.data);
      } catch (err) {
        console.error('Error loading stats', err);
      }
    };

    const fetchEarnings = async () => {
      try {
        const res = await getAffiliateEarnings();
        setEarnings(res.data.totalEarned ?? 0);
      } catch (err) {
        console.error('Error loading affiliate earnings', err);
      }
    };

    fetchStats();
    fetchEarnings();
  }, [user, isUser, navigate]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const quickActions = [
    {
      icon: '📘',
      title: 'PDF Library',
      desc: 'Access and download study materials',
      route: '/pdf-library',
      color: '#3b82f6',
    },
    {
      icon: '🧪',
      title: 'Available Tests',
      desc: 'Take practice tests and quizzes',
      route: '/tests/list',
      color: '#10b981',
    },
    {
      icon: '📊',
      title: 'Test Results',
      desc: 'View your performance history',
      route: '/results',
      color: '#8b5cf6',
    },
    {
      icon: '⭐',
      title: 'Bookmarks',
      desc: 'Your saved questions and materials',
      route: '/bookmarks',
      color: '#f59e0b',
    },
    {
      icon: '🔔',
      title: 'Notifications',
      desc: 'Check latest updates and alerts',
      route: '/notifications',
      color: '#ef4444',
    },
    {
      icon: '👤',
      title: 'Profile',
      desc: 'Manage your account settings',
      route: '/profile',
      color: '#6b7280',
    },
    {
      icon: '🎓',
      title: 'Courses',
      desc: 'Explore all available courses',
      route: '/courses',
      color: '#facc15',
    },
  ];

  const renderSection = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
            <div style={cardStyle('#3b82f6')}>
              <h3>📊 Total Tests Taken</h3>
              <p>{stats?.totalTests ?? '0'}</p>
            </div>
            <div style={cardStyle('#10b981')}>
              <h3>🎯 Average Score</h3>
              <p>{stats?.avgScore ?? '0'}%</p>
            </div>
            <div style={cardStyle('#f59e0b')}>
              <h3>⭐ Bookmarked Items</h3>
              <p>{stats?.bookmarks ?? '0'}</p>
            </div>
            <div style={cardStyle('#6366f1')}>
              <h3>💰 Affiliate Earnings</h3>
              <p>₹{earnings.toFixed(2)}</p>
            </div>
          </div>
        );

      case 'quick-actions':
        return (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
            {quickActions.map(({ icon, title, desc, route, color }) => (
              <div
                key={title}
                onClick={() => navigate(route)}
                style={quickActionStyle(color)}
              >
                <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>{icon}</div>
                <h3>{title}</h3>
                <p>{desc}</p>
              </div>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  const cardStyle = (color) => ({
    backgroundColor: '#fff',
    padding: '1.5rem',
    borderRadius: '8px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
    border: '1px solid #e5e7eb',
    color: color,
    fontSize: '2rem',
    fontWeight: 'bold',
  });

  const quickActionStyle = (bgColor) => ({
    backgroundColor: bgColor,
    color: 'white',
    padding: '1.5rem',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    boxShadow: `0 2px 10px ${bgColor}50`,
  });

  const tabs = [
    { key: 'overview', label: '📊 Overview' },
    { key: 'quick-actions', label: '🚀 Quick Actions' },
  ];

  if (!user || !isUser) {
    return null;
  }

  return (
    <div style={{ padding: '2rem', backgroundColor: '#f9fafb', minHeight: '100vh' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <h1 style={{ fontSize: '1.8rem', fontWeight: 'bold', color: '#111827' }}>
            👋 Welcome, {user?.name || user?.email}
          </h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ color: '#6b7280', fontSize: '0.9rem' }}>{user?.email}</span>
            <button
              onClick={handleLogout}
              style={{
                backgroundColor: '#dc3545',
                color: 'white',
                border: 'none',
                padding: '0.5rem 1rem',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '0.9rem',
                fontWeight: '500',
              }}
            >
              Logout
            </button>
          </div>
        </header>

        <nav style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              style={{
                padding: '0.6rem 1rem',
                borderRadius: '6px',
                border: activeTab === tab.key ? '2px solid #3b82f6' : '1px solid #d1d5db',
                backgroundColor: activeTab === tab.key ? '#eff6ff' : '#fff',
                cursor: 'pointer',
                fontWeight: activeTab === tab.key ? '600' : '500',
                color: activeTab === tab.key ? '#1e40af' : '#374151',
                transition: 'all 0.2s ease-in-out',
              }}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        <main>{renderSection()}</main>
      </div>
    </div>
  );
}
