// src/pages/bookmarks/Bookmarks.jsx
import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import API from '../services/api';

export default function Bookmarks() {
  const { user } = useAuth();
  const [bookmarks, setBookmarks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBookmarks = async () => {
    try {
      const res = await API.get(`/bookmarks/${user._id}`);
      setBookmarks(res.data);
    } catch (err) {
      console.error('Failed to fetch bookmarks:', err);
      setError('Could not load bookmarks');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?._id) fetchBookmarks();
  }, [user]);

  const removeBookmark = async (qid) => {
    try {
      await API.delete('/bookmarks', {
        data: { userId: user._id, questionId: qid },
      });
      setBookmarks((prev) => prev.filter((b) => b._id !== qid));
    } catch (err) {
      alert('❌ Failed to remove bookmark');
    }
  };

  if (loading) return <div className="p-6">Loading bookmarks...</div>;
  if (error) return <div className="p-6 text-red-500">{error}</div>;

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">⭐ Your Bookmarked Questions</h2>
      {bookmarks.length === 0 ? (
        <p>You haven't bookmarked anything yet.</p>
      ) : (
        <ul className="space-y-4">
          {bookmarks.map((q) => (
            <li key={q._id} className="bg-white p-4 rounded shadow flex justify-between">
              <p className="text-gray-800 font-medium">{q.questionText}</p>
              <button
                onClick={() => removeBookmark(q._id)}
                className="text-red-600 underline"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
