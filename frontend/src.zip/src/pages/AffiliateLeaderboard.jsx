import React, { useEffect, useState } from 'react';
import { getLeaderboard } from '../services/api';

const AffiliateLeaderboard = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    getLeaderboard().then((res) => setData(res.data));
  }, []);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Affiliate Leaderboard</h1>
      <table className="w-full table-auto border">
        <thead>
          <tr className="bg-gray-100">
            <th className="border px-4 py-2">#</th>
            <th className="border px-4 py-2">User</th>
            <th className="border px-4 py-2">Email</th>
            <th className="border px-4 py-2">Earnings (₹)</th>
          </tr>
        </thead>
        <tbody>
          {data.map((u, i) => (
            <tr key={u.email}>
              <td className="border px-4 py-2">{i + 1}</td>
              <td className="border px-4 py-2">{u.name}</td>
              <td className="border px-4 py-2">{u.email}</td>
              <td className="border px-4 py-2">{u.totalCommission.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AffiliateLeaderboard;
