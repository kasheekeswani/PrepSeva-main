import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getCourseById, createOrder, verifyPurchase } from '../services/api';
import { useAuth } from '../context/AuthContext';

const CourseDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);

  useEffect(() => {
    getCourseById(id)
      .then((res) => {
        setCourse(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [id]);

  const loadRazorpay = async () => {
    setPurchasing(true);
    try {
      const { data } = await createOrder(course._id, user._id);
      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY_ID,
        amount: data.order.amount,
        currency: 'INR',
        name: 'Affiliate Course Purchase',
        description: course.title,
        order_id: data.order.id,
        handler: async (response) => {
          try {
            await verifyPurchase({
              courseId: course._id,
              affiliateId: user._id,
              paymentId: response.razorpay_payment_id,
            });
            alert('✅ Purchase Successful!');
          } catch {
            alert('❌ Payment verification failed.');
          }
        },
        prefill: {
          name: user.name,
          email: user.email,
        },
        theme: { color: '#3B82F6' },
      };
      new window.Razorpay(options).open();
    } catch {
      alert('❌ Failed to initiate payment.');
    } finally {
      setPurchasing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="animate-spin rounded-full border-t-4 border-blue-500 w-12 h-12"></div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center p-4">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Course Not Found</h2>
        <p className="text-gray-600 mb-4">This course does not exist or was removed.</p>
        <button
          onClick={() => navigate(-1)}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
        >
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-3xl mx-auto p-6 bg-white rounded-3xl shadow-xl mt-6">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-64 object-cover rounded-2xl mb-4"
        />
        <h1 className="text-2xl font-bold mb-2">{course.title}</h1>
        <p className="text-gray-700 mb-4">{course.description}</p>
        <div className="flex justify-between items-center bg-gray-50 p-4 rounded-xl mb-4">
          <div className="font-semibold">Price: ₹{course.price}</div>
          <div className="text-green-600 font-semibold">Commission: {course.affiliateCommission}%</div>
        </div>
        {user?.role === 'user' && (
          <button
            onClick={loadRazorpay}
            disabled={purchasing}
            className="w-full bg-blue-600 text-white font-semibold py-3 rounded-xl hover:bg-blue-700 transition"
          >
            {purchasing ? 'Processing...' : 'Buy Now'}
          </button>
        )}
        {user?.role === 'admin' && (
          <div className="text-center mt-4 text-purple-600 font-semibold">Admin Preview Mode</div>
        )}
      </div>
    </div>
  );
};

export default CourseDetails;
