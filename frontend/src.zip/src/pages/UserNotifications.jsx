// src/pages/notifications/UserNotifications.jsx
import { useEffect, useState } from 'react';
import API from '../services/api';

export default function UserNotifications() {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await API.get('/notifications');
        setNotes(res.data);
      } catch (err) {
        console.error('Error loading notifications:', err);
        setError('Failed to load notifications');
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  if (loading) return <div className="p-6">Loading notifications...</div>;
  if (error) return <div className="p-6 text-red-500">{error}</div>;

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">🔔 Notifications</h2>
      {notes.length === 0 ? (
        <p>No announcements yet.</p>
      ) : (
        <ul className="space-y-4">
          {notes.map((n) => (
            <li
              key={n._id}
              className="bg-white p-4 rounded shadow border-l-4 border-blue-500"
            >
              <h4 className="font-semibold">{n.title}</h4>
              <p className="text-gray-600 text-sm">{n.message}</p>
              <p className="text-xs text-gray-400 mt-1">
                {new Date(n.createdAt).toLocaleString()}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
