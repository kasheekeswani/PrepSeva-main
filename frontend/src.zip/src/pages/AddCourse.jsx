// admin-panel/src/pages/AddCourse.jsx
import React, { useState } from 'react';
import { createCourse } from '../services/api';
import { useNavigate } from 'react-router-dom';

const AddCourse = () => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    price: '',
    affiliateCommission: '',
  });
  const [thumbnail, setThumbnail] = useState(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = new FormData();
      Object.entries(form).forEach(([key, val]) => data.append(key, val));
      data.append('thumbnail', thumbnail);

      await createCourse(data);
      alert('✅ Course added successfully!');
      navigate('/courses');
    } catch (err) {
      console.error('❌ Error submitting course:', err);
      alert(err.response?.data?.message || 'Failed to add course');
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Add New Course</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          name="title"
          placeholder="Course Title"
          value={form.title}
          onChange={handleChange}
          required
          style={styles.input}
        />
        <textarea
          name="description"
          placeholder="Course Description"
          value={form.description}
          onChange={handleChange}
          required
          style={{ ...styles.input, height: '80px' }}
        />
        <input
          name="price"
          type="number"
          placeholder="Price (₹)"
          value={form.price}
          onChange={handleChange}
          required
          style={styles.input}
        />
        <input
          name="affiliateCommission"
          type="number"
          placeholder="Affiliate Commission %"
          value={form.affiliateCommission}
          onChange={handleChange}
          required
          style={styles.input}
        />
        <input
          type="file"
          onChange={(e) => setThumbnail(e.target.files[0])}
          required
          style={{ ...styles.input, border: 'none' }}
        />
        <button type="submit" style={styles.button}>
          Submit Course
        </button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '500px',
    margin: '60px auto',
    padding: '30px',
    background: '#f9f9f9',
    borderRadius: '8px',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)',
    fontFamily: 'Arial, sans-serif',
  },
  heading: {
    marginBottom: '20px',
    fontSize: '22px',
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#333',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  input: {
    padding: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '14px',
  },
  button: {
    backgroundColor: '#28a745',
    color: 'white',
    padding: '10px',
    border: 'none',
    fontWeight: 'bold',
    cursor: 'pointer',
    borderRadius: '4px',
  },
};

export default AddCourse;
