// src/pages/PDFLibrary.jsx
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import API from '../services/api';

export default function PDFLibrary() {
  const { user } = useAuth(); // ✅ Added auth check
  const navigate = useNavigate();

  const [pdfs, setPdfs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null); // ✅ Improve UX

  useEffect(() => {
    if (!user) return navigate('/'); // ✅ Redirect if not logged in

    const fetchPDFs = async () => {
      try {
        const res = await API.get('/pdfs');
        setPdfs(res.data);
      } catch (err) {
        console.error('Error fetching PDFs:', err);
        setError('Unable to load PDFs. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchPDFs();
  }, [user, navigate]);

  const handleDownload = async (pdf) => {
    setDownloadingId(pdf._id);
    try {
      await API.post('/pdfs/track-download', { pdfId: pdf._id });
      window.open(pdf.pdfUrl, '_blank');
    } catch (err) {
      console.error('Failed to track/download PDF:', err);
      alert('Something went wrong while downloading.');
    } finally {
      setDownloadingId(null);
    }
  };

  if (loading) return <div className="p-6">📄 Loading PDFs...</div>;
  if (error) return <div className="p-6 text-red-500">{error}</div>;

  return (
    <div className="p-6 min-h-screen bg-gray-50">
      <h2 className="text-2xl font-bold mb-4">📘 Previous Year Papers</h2>

      {pdfs.length === 0 ? (
        <p>No PDFs available right now.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {pdfs.map((pdf) => (
            <div
              key={pdf._id}
              className="bg-white rounded shadow p-4 flex flex-col justify-between"
            >
              <div>
                <h3 className="font-semibold text-lg">{pdf.title}</h3>
                <p className="text-sm text-gray-500">
                  {pdf.examName} - {pdf.year}
                </p>
              </div>
              <button
                onClick={() => handleDownload(pdf)}
                className={`mt-4 px-4 py-2 rounded text-white ${
                  downloadingId === pdf._id
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
                disabled={downloadingId === pdf._id}
              >
                {downloadingId === pdf._id ? 'Downloading...' : 'Download PDF'}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
