import { useEffect, useState } from 'react';
import API from '../services/api';

export default function PdfManager() {
  const [pdfs, setPdfs] = useState([]);
  const [title, setTitle] = useState('');
  const [examName, setExamName] = useState('');
  const [year, setYear] = useState('');
  const [file, setFile] = useState(null);

  const fetchPDFs = async () => {
    const { data } = await API.get('/pdfs');
    setPdfs(data);
  };

  useEffect(() => {
    fetchPDFs();
  }, []);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return alert('Choose a file');

    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title);
    formData.append('examName', examName);
    formData.append('year', year);

    try {
      await API.post('/pdfs/upload', formData);
      alert('Uploaded');
      setTitle('');
      setYear('');
      setExamName('');
      setFile(null);
      fetchPDFs();
    } catch (err) {
      alert('Upload failed');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete PDF?')) return;
    await API.delete(`/pdfs/${id}`);
    fetchPDFs();
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>
        PDF Upload Manager
      </h2>

      <form
        onSubmit={handleUpload}
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '1rem',
          backgroundColor: 'white',
          boxShadow: '0 0 10px rgba(0,0,0,0.1)',
          padding: '1.5rem',
          borderRadius: '8px',
          maxWidth: '600px',
          marginBottom: '2rem'
        }}
      >
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{ padding: '0.5rem', border: '1px solid #ccc', borderRadius: '4px', width: '100%' }}
        />
        <input
          type="text"
          placeholder="Exam Name"
          value={examName}
          onChange={(e) => setExamName(e.target.value)}
          style={{ padding: '0.5rem', border: '1px solid #ccc', borderRadius: '4px', width: '100%' }}
        />
        <input
          type="text"
          placeholder="Year"
          value={year}
          onChange={(e) => setYear(e.target.value)}
          style={{ padding: '0.5rem', border: '1px solid #ccc', borderRadius: '4px', width: '100%' }}
        />
        <input
          type="file"
          accept=".pdf"
          onChange={(e) => setFile(e.target.files[0])}
          style={{ padding: '0.5rem', width: '100%' }}
        />
        <button
          type="submit"
          style={{
            backgroundColor: '#007bff',
            color: 'white',
            padding: '0.75rem',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Upload PDF
        </button>
      </form>

      <div>
        <h3 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem' }}>
          Uploaded PDFs
        </h3>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {pdfs.map((pdf) => (
            <li
              key={pdf._id}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                backgroundColor: '#f0f0f0',
                padding: '1rem',
                borderRadius: '6px',
                marginBottom: '0.75rem'
              }}
            >
              <div>
                <p style={{ fontWeight: '600', margin: 0 }}>{pdf.title}</p>
                <p style={{ fontSize: '0.875rem', margin: 0 }}>
                  {pdf.examName} - {pdf.year}
                </p>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <a
                  href={pdf.pdfUrl}
                  target="_blank"
                  rel="noreferrer"
                  style={{ color: '#007bff', textDecoration: 'underline' }}
                >
                  View
                </a>
                <button
                  onClick={() => handleDelete(pdf._id)}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: 'red',
                    textDecoration: 'underline',
                    cursor: 'pointer'
                  }}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
