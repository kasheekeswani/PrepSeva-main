// admin-panel/src/services/api.js
import axios from 'axios'

const API = axios.create({
  baseURL: 'http://localhost:5000/api',
  withCredentials: true,
})

// ✅ Intercept and attach token to all requests
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  
  // 🔍 DEBUG: Log token status
  console.log('🔍 Request interceptor fired');
  console.log('🔍 Token from localStorage:', token);
  console.log('🔍 Request URL:', config.url);
  console.log('🔍 Request method:', config.method);
  
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
    console.log('✅ Authorization header set:', config.headers['Authorization']);
  } else {
    console.log('❌ No token found in localStorage');
  }
  
  // 🔍 DEBUG: Log all headers
  console.log('🔍 All request headers:', config.headers);
  
  return config;
});

// ✅ Add response interceptor for debugging
API.interceptors.response.use(
  (response) => {
    console.log('✅ Response success:', response.status);
    return response;
  },
  (error) => {
    console.log('❌ Response error:', error.response?.status);
    console.log('❌ Error message:', error.response?.data?.message);
    return Promise.reject(error);
  }
);

// ✅ Course Service Functions
export const fetchCourses = () => API.get('/courses');
export const createCourse = (formData) => {
  console.log('🔍 createCourse called with:', formData);
  return API.post('/courses', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

// ✅ Affiliate Service Functions
export const createOrder = (courseId, affiliateCode) =>
  API.post('/affiliate/order', { courseId, affiliateCode });
export const verifyPurchase = (data) => API.post('/affiliate/verify', data);
export const getAffiliateEarnings = () => API.get('/affiliate/earnings');
export const getLeaderboard = () => API.get('/affiliate/leaderboard');

// ✅ Get single course by ID
export const getCourseById = (id) => API.get(`/courses/${id}`);

// ✅ Update a course (admin only)
export const updateCourse = (id, formData) => {
  return API.put(`/courses/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
};

// ✅ New Affiliate Link Service Functions
export const createAffiliateLink = (data) => API.post('/affiliate-links', data);
export const getAffiliateLinks = () => API.get('/affiliate-links');
export const updateAffiliateLink = (id, data) => API.put(`/affiliate-links/${id}`, data);
export const deleteAffiliateLink = (id) => API.delete(`/affiliate-links/${id}`);
export const getAffiliateLinkById = (id) => API.get(`/affiliate-links/${id}`);

// ✅ Affiliate Link Analytics
export const getAffiliateLinkAnalytics = (period = '30d') => 
  API.get(`/affiliate-links/analytics?period=${period}`);
export const getAffiliateLinkStats = (id) => 
  API.get(`/affiliate-links/${id}/stats`);

// ✅ QR Code Generation
export const generateQRCode = (id) => 
  API.get(`/affiliate-links/${id}/qr-code`, { responseType: 'blob' });

// ✅ Link Tracking (Public endpoints - no auth required)
export const trackClick = (code) => 
  axios.post(`${API.defaults.baseURL}/affiliate-links/track/${code}`);

// ✅ Export the main API instance as default
export default API